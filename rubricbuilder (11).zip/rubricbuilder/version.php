<?php
/**
 * Version information for local_rubricbuilder.
 *
 * @package   local_rubricbuilder
 * @copyright 2026 Equip English
 * @license   https://www.gnu.org/licenses/gpl-3.0.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_rubricbuilder';
$plugin->version   = 2026090303;
$plugin->requires  = 2022112800; // Moodle 4.1+
$plugin->maturity  = MATURITY_BETA;
$plugin->release   = '0.6';
